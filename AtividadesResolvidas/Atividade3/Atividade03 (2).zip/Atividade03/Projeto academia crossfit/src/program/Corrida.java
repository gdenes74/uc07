package program;

public class Corrida extends Exercicio {
	public Corrida(String nome) {
		super(nome);

	}

}
