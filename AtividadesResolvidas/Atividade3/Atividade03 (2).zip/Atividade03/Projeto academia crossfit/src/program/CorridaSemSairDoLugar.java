package program;

public class CorridaSemSairDoLugar extends Corrida{

	public CorridaSemSairDoLugar() {
		super("Corrida sem sair do lugar");
		// TODO Auto-generated constructor stub
	}

}
