package program;

public class PularCorda extends Corrida {
	public PularCorda() {
		super("Pular Corda");
		// TODO Auto-generated constructor stub
	}
}
