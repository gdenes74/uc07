package program;

public class Supino extends Musculacao {

	public Supino() {
		super("Supino");

	}

}
