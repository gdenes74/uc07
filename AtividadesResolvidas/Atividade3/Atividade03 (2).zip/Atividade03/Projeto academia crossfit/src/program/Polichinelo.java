package program;

public class Polichinelo extends Musculacao {

	public Polichinelo() {
		super("Polichinelo");
		// TODO Auto-generated constructor stub
	}

}
