package program;

public class Musculacao extends Exercicio {
	public Musculacao(String nome) {
		super(nome);

	}

}
