package program;

interface Modelo {
	Corrida getCorrida();
	Musculacao getMusculacao();
}
